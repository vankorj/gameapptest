'use strict';

class FoodConsumed {

    constructor(foodId, playerId) {
        this.foodId = foodId;
        this.playerId = playerId;
    }
}

module.exports = FoodConsumed;
